<?php

class Laporan extends CI_Controller{
	public function index()
{
$data['laporan']=$this->m_laporan->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('laporan', $data);
		$this->load->view('templates/footer');

	}

public function tambah_aksi(){
	$kode_transaksi 	= $this->input->post('kode_transaksi');
	$tanggal 			= $this->input->post('tanggal');
	$barang_masuk 		= $this->input->post('barang_masuk');
	$jumlah 		    = $this->input->post('jumlah');
	$biaya 				= $this->input->post('biaya');
	$satuan 			= $this->input->post('satuan');

	$data = array(
		'kode_transaksi' 	=> $kode_transaksi,
		'tanggal' 			=> $tanggal,
		'barang_masuk' 		=> $barang_masuk,
		'jumlah' 			=> $jumlah,
		'biaya' 			=> $biaya,
		'satuan' 			=> $satuan,

	);

	$this->m_laporan->input_data($data, 'tb_laporan');
	redirect('laporan/index');

}

public function hapus ($id)
 	{
		$where = array ('id' => $id);
		$this->m_dataobat->hapus_data($where, 'data_obat');
		redirect ('data_obat/index');
	}

public function print(){
	$data['laporan'] = $this->m_laporan->tampil_data("tb_laporan")->result();
	$this->load->view('print_laporan',$data);
	

}


}