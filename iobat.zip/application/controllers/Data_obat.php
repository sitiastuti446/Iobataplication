<?php

class Data_obat extends CI_Controller{
	public function index()
{
$data['data_obat']=$this->m_dataobat->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('data_obat',$data);
		$this->load->view('templates/footer');
	}
public function tambah_aksi(){
	$kode_obat 		= $this->input->post('kode_obat');
	$nama_obat 		= $this->input->post('nama_obat');
	$harga_beli 	= $this->input->post('harga_beli');
	$stok 		    = $this->input->post('stok');
	$satuan 		= $this->input->post('satuan');

	$data = array(
		'kode_obat' 	=> $kode_obat,
		'nama_obat' 	=> $nama_obat,
		'harga_beli' 	=> $harga_beli,
		'stok' 			=> $stok,
		'satuan' 		=> $satuan,

	);

	$this->m_dataobat->input_data($data, 'data_obat');
	redirect('data_obat/index');
}
 	public function hapus ($id)
 	{
		$where = array ('id' => $id);
		$this->m_dataobat->hapus_data($where, 'data_obat');
		redirect ('data_obat/index');
	}

	public function edit ($id)
	{
		$where = array('id' =>$id);
		$data['data_obat'] = $this->m_dataobat->edit_data($where,'data_obat')->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('dataobat/edit', $data);
		$this->load->view('templates/footer');
	}
	
	public function update(){
	$id 		    = $this->input->post('id');
	$kode_obat 		= $this->input->post('kode_obat');
	$nama_obat 		= $this->input->post('nama_obat');
	$harga_beli 	= $this->input->post('harga_beli');
	$stok 		    = $this->input->post('stok');
	$satuan 		= $this->input->post('satuan');

		$data = array(
		'kode_obat' 	=> $kode_obat,
		'nama_obat' 	=> $nama_obat,
		'harga_beli' 	=> $harga_beli,
		'stok' 			=> $stok,
		'satuan' 		=> $satuan,

	);
		$where = array(
			'id' => $id
		);

		$this->m_dataobat->update_data($where,$data,'data_obat');
		redirect('data_obat/index');


}		


}