<?php
class Manajemen_user extends CI_Controller {
	public function index()
	{
$data['manajemen_user']=$this->m_manajemenuser->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('manajemen_user', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_aksi(){
	$nama 				= $this->input->post('nama');
	$username 			= $this->input->post('username');
	$hak_akses 			= $this->input->post('hak_akses');
	$status 		    = $this->input->post('status');

	$data = array(
		'nama' 				=> $nama,
		'username' 			=> $username,
		'hak_akses' 		=> $hak_akses,
		'status' 			=> $status,

	);

	$this->m_manajemenuser->input_data($data, 'manajemen_user');
	redirect('manajemen_user/index');

}
 	public function hapus ($id)
 	{
		$where = array ('id' => $id);
		$this->m_manajemenuser->hapus_data($where, 'manajemen_user');
		redirect ('manajemen_user/index');
	}


}		


