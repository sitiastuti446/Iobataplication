<?php

class Data_obatmasuk extends CI_Controller{
	public function index()
{
$data['data_obatmasuk']=$this->m_data_obatmasuk->tampil_data()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('data_obatmasuk',$data);
		$this->load->view('templates/footer');
	}

public function tambah_aksi(){
	$kode_transaksi 		= $this->input->post('kode_transaksi');
	$tanggal 				= $this->input->post('tanggal');
	$kode_obat 				= $this->input->post('kode_obat');
	$nama_obat 		    	= $this->input->post('nama_obat');
	$jumlah_masuk 		    = $this->input->post('jumlah_masuk');
	$satuan 				= $this->input->post('satuan');

	$data = array(
		'kode_transaksi' 	=> $kode_transaksi,
		'tanggal' 			=> $tanggal,
		'kode_obat' 		=> $kode_obat,
		'nama_obat' 		=> $nama_obat,
		'jumlah_masuk' 		=> $jumlah_masuk,
		'satuan' 			=> $satuan,

	); 

	$this->m_data_obatmasuk->input_data($data, 'tb_obatmasuk');
	redirect('data_obatmasuk');
}

 	public function hapus ($id)
 	{
		$where = array ('id' => $id);
		$this->m_data_obatmasuk->hapus_data($where, 'tb_obatmasuk');
		redirect ('data_obatmasuk/index');
	}

	public function edit($id)
	{
		$where = array('id' =>$id);
		$data['data_obatmasuk'] = $this->m_data_obatmasuk->edit_data($where, 'tb_obatmasuk')->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('edit', $data);
		$this->load->view('templates/footer');
	}

public function update(){
		$kode_transaksi 	= $this->input->post('kode_transaksi');
		$tanggal 			= $this->input->post('tanggal');
		$kode_obat		    = $this->input->post('kode_obat');
		$nama_obat 			= $this->input->post('nama_obat');
		$jumlah_masuk 		= $this->input->post('jumlah_masuk');
		$satuan 			= $this->input->post('satuan');

	$data = array(
		'kode_transaksi' 	=> $kode_transaksi,
		'tanggal' 			=> $tanggal,
		'kode_obat' 		=> $kode_obat,
		'nama_obat' 		=> $nama_obat,
		'jumlah_masuk' 		=> $jumlah_masuk,
		'satuan' 			=> $satuan,

	);

	$where = array(
		'id' => $id
	);

	$this->m_data_obatmasuk->update($where,$data,'tb_obatmasuk');
	redirect('data_obatmasuk/index');	
}		

}