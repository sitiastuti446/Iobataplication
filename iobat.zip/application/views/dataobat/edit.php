<div class="container-fluid">
<h3><i class="fas fa-edit"></i>Edit Barang Masuk</h3>

		<?php foreach($data_obat as $dt_obt) { ?>

		<form action="<?php echo base_url().'data_obat/update'; ?>" method="post">

			<div class="form-group">
				<label>Kode Obat</label>
				<input type="hidden" name="id" class="form-control" 
				value="<?php echo $dt_obt->id ?>">
				<input type="text" name="kode_obat" class="form-control" 
				value="<?php echo $dt_obt->kode_obat ?>">
			</div>

			<div class="form-group">
				<label>Nama Obat</label>
				<input type="text" name="nama_obat" class="form-control" 
				value="<?php echo $dt_obt->nama_obat ?>">
			</div>

			<div class="form-group">
				<label>Harga Beli</label>
				<input type="text" name="harga_beli" class="form-control" 
				value="<?php echo $dt_obt->harga_beli ?>">
			</div>

			<div class="form-group">
				<label>Stok</label>
				<input type="text" name="stok" class="form-control" 
				value="<?php echo $dt_obt->stok ?>">
			</div>

			<div class="form-group">
				<label>Satuan</label>
				<input type="text" name="satuan" class="form-control" 
				value="<?php echo $dt_obt->satuan ?>">
			</div>
			
			<button type="submit" class="btn btn-danger">Reset</button>
			<button type="submit" class="btn btn-primary">Simpan</button>

		</form>
		<?php } ?>
	</section>

</div>



