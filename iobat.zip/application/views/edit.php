
<div class="container-fluid">
<h3><i class="fas fa-edit"></i>Edit Barang Masuk</h3>

    <?php foreach($data_obatmasuk as $dt_obtmsk) { ?>

    <form action="<?php echo base_url().'data_obatmasuk/update'; ?>" method="post">

      <div class="form-group">
        <label>Kode Transaksi</label>
        <input type="hidden" name="id" class="form-control" 
        value="<?php echo $dt_obtmsk->id ?>">
        <input type="text" name="kode_obat" class="form-control" 
        value="<?php echo $dt_obtmsk->kode_transaksi ?>">
      </div>

      <div class="form-group">
        <label>Tanggal</label>
        <input type="text" name="tanggal" class="form-control" 
        value="<?php echo $dt_obtmsk->tanggal ?>">
      </div>

      <div class="form-group">
        <label>Kode Obat</label>
        <input type="text" name="kode_obat" class="form-control" 
        value="<?php echo $dt_obtmsk->kode_obat ?>">
      </div>

      <div class="form-group">
        <label>Nama Obat</label>
        <input type="text" name="nama_obat" class="form-control" 
        value="<?php echo $dt_obtmsk->nama_obat ?>">
      </div>

      <div class="form-group">
        <label>Jumlah Masuk</label>
        <input type="text" name="jumlah_masuk" class="form-control" 
        value="<?php echo $dt_obtmsk->jumlah_masuk ?>">
      </div>
      
      
      <button type="submit" class="btn btn-primary">Simpan</button>

    </form>
    <?php } ?>
  </section>

</div>



