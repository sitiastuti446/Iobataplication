
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Obat</h1>
          </div>

<section class="content">
  <button class="btn btn-primary mb-4" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data Obat</button>
  <table class="table">
    <tr>
      <th>No</th>
      <th>Kode Obat</th>
      <th>Nama Obat</th>
      <th>Harga Beli</th>
      <th>Stok</th>
      <th>Satuan</th>
      <th colspan="2">Aksi</th>
    </tr>
    <?php

    $no = 1;
    foreach ($data_obat as $dt_obt) : ?>
      <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $dt_obt->kode_obat ?></td>
        <td><?php echo $dt_obt->nama_obat ?></td>
        <td><?php echo $dt_obt->harga_beli ?></td>
        <td><?php echo $dt_obt->stok ?></td>
        <td><?php echo $dt_obt->satuan ?></td>
        <td onclick="javascript: return confirm('Anda yakin hapus?')"><?php echo anchor('data_obat/hapus/'.$dt_obt->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>
         <td><?php echo anchor('data_obat/edit/'.$dt_obt->id,'<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>') ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
  
</section>




<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Input Data Obat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url(). 'data_obat/tambah_aksi' ?>">
          
          <div class="form-group">
            <label>Kode Obat</label>
            <input type="text" name="kode_obat" class="form-control">

          <div class="form-group">
            <label>Nama Obat</label>
            <input type="text" name="nama_obat" class="form-control">

            <div class="form-group">
            <label>Harga Beli</label>
            <input type="text" name="harga_beli" class="form-control">

            <div class="form-group">
            <label>Stok</label>
            <input type="text" name="stok" class="form-control">
            

            <div class="form-group">
            <label>Satuan</label>
            <input type="text" name="satuan" class="form-control">
          </div>

            <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
      
    </div>
  </div>
</div>