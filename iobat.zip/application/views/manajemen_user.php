 <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Manajemen User</h1>
          </div>

<section class="content">
  <button class="btn btn-primary mb-4" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data User</button>
  <table class="table">
    <tr>
      <th>No</th>
      <th>Nama</th>
      <th>Username</th>
      <th>Hak Akses</th>
      <th>Status</th>
      <th colspan="2">Aksi</th>
    </tr>

    <?php

    $no = 1;
    foreach ($manajemen_user as $mnj_usr) : ?>
      <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $mnj_usr->nama ?></td>
        <td><?php echo $mnj_usr->username ?></td>
        <td><?php echo $mnj_usr->hak_akses ?></td>
        <td><?php echo $mnj_usr->status ?></td>
        <td onclick="javascript: return confirm('Anda yakin hapus?')"><?php echo anchor('manajemen_user/hapus/'.$mnj_usr->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>
        
      </tr>
    <?php endforeach; ?>
  </table>
  
</section>

  </table>
  
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Input Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url(). 'manajemen_user/tambah_aksi' ?>">
          
          <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control">

          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control">

            <div class="form-group">
            <label>Hak Akses</label>
            <input type="text" name="hak_akses" class="form-control">

            <div class="form-group">
            <label>Status</label>
            <input type="text" name="status" class="form-control">

            <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
      
    </div>
  </div>
</div>
  