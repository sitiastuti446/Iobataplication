<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<table>
		<th>No</th>
		<th>Kode Transaksi</th>
		<th>Tanggal</th>
		<th>Barang Masuk</th>
		<th>Jumlah</th>
		<th>Biaya</th>
		<th>Satuan</th>
    </th>
    <?php

    $no = 1;
    foreach ($laporan as $lpr) : ?>
      <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $lpr->kode_transaksi ?></td>
        <td><?php echo $lpr->tanggal ?></td>
        <td><?php echo $lpr->barang_masuk ?></td>
        <td><?php echo $lpr->jumlah ?></td>
        <td><?php echo $lpr->biaya ?></td>
        <td><?php echo $lpr->satuan ?></td>
      </tr>
     <?php endforeach; ?>
	</table>
<script type="text/javascript">
	window.print();
</script>
</body>
</html>