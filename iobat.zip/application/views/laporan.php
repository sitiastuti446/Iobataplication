
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Laporan Transaksi</h1>
          </div>

<section class="content">
  <button class="btn btn-primary mb-4" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data Transaksi</button>

  <a class="btn btn-danger mb-4" href="<?php echo base_url('laporan/print') ?>">
      <i class="fa fa-print"></i> Print</a> 
 
  <table class="table">
    <tr>
      <th>No</th>
      <th>Kode Transaksi</th>
      <th>Tanggal</th>
      <th>Barang Masuk</th>
      <th>Jumlah</th>
      <th>Biaya</th>
      <th>Satuan</th>
      <th colspan="2">Aksi</th>
    </tr>
    <?php

    $no = 1;
    foreach ($laporan as $lpr) : ?>
      <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $lpr->kode_transaksi ?></td>
        <td><?php echo $lpr->tanggal ?></td>
        <td><?php echo $lpr->barang_masuk ?></td>
        <td><?php echo $lpr->jumlah ?></td>
        <td><?php echo $lpr->biaya ?></td>
        <td><?php echo $lpr->satuan ?></td>
        <td onclick="javascript: return confirm('Anda yakin hapus?')"><?php echo anchor('laporan/hapus/'.$lpr->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
  
</section>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Input Data Transaksi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url(). 'laporan/tambah_aksi' ?>">
          
          <div class="form-group">
            <label>Kode Transaksi</label>
            <input type="text" name="kode_transaksi" class="form-control">

          <div class="form-group">
            <label>Tanggal</label>
            <input type="date" name="tanggal" class="form-control">

            <div class="form-group">
            <label>Barang Masuk</label>
            <input type="text" name="barang_masuk" class="form-control">

            <div class="form-group">
            <label>Jumlah</label>
            <input type="text" name="jumlah" class="form-control">
            

            <div class="form-group">
            <label>Biaya</label>
            <input type="text" name="biaya" class="form-control">

            <div class="form-group">
            <label>Satuan</label>
            <input type="text" name="satuan" class="form-control">
          </div>

            <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
      
    </div>
  </div>
</div>




