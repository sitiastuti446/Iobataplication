-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2020 at 05:01 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poliklinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_obat`
--

CREATE TABLE `data_obat` (
  `id` int(7) NOT NULL,
  `kode_obat` int(100) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `harga_beli` varchar(100) NOT NULL,
  `stok` int(200) NOT NULL,
  `satuan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_obat`
--

INSERT INTO `data_obat` (`id`, `kode_obat`, `nama_obat`, `harga_beli`, `stok`, `satuan`) VALUES
(1, 111, 'Neuralgin', 'Rp.300.000,00', 400, 'Tablet'),
(4, 112, 'Cetirizine', 'Rp.200.000,00', 200, 'Tablet'),
(6, 113, 'Cetirizine', 'Rp.500.000,00', 200, 'Tablet'),
(7, 114, 'OBH Combi', 'Rp.400.000,00', 35, 'Botol'),
(8, 115, 'Pharmaton', 'Rp.400.000,00', 200, 'Capsul');

-- --------------------------------------------------------

--
-- Table structure for table `manajemen_user`
--

CREATE TABLE `manajemen_user` (
  `id` int(7) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `hak_akses` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manajemen_user`
--

INSERT INTO `manajemen_user` (`id`, `nama`, `username`, `hak_akses`, `status`) VALUES
(3, 'Siti Astuti', 'Astuti', 'Super Admin', 'Aktif'),
(4, 'Shapira Aprillia', 'Shapira', 'Manajer', 'Aktif'),
(5, 'Adella Satriani', 'Adel', 'Gudang', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `status` enum('aktif','tidak aktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `nama`, `username`, `password`, `role_id`, `status`) VALUES
(1, 'Astuti', 'Astuti', 'admin', 1, 'aktif'),
(2, 'Shapira', 'Shapira', 'manajer', 2, 'aktif'),
(3, 'Adel', 'Adel', 'gudang', 3, 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_laporan`
--

CREATE TABLE `tb_laporan` (
  `id` int(11) NOT NULL,
  `kode_transaksi` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `barang_masuk` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `biaya` varchar(100) NOT NULL,
  `satuan` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_laporan`
--

INSERT INTO `tb_laporan` (`id`, `kode_transaksi`, `tanggal`, `barang_masuk`, `jumlah`, `biaya`, `satuan`) VALUES
(1, 'A118976', '2020-06-23', 'OBH Combi Madu', 20, 'Rp.300.000,00', 'Botol'),
(2, 'B11679', '2019-12-29', 'Panadol', 100, 'Rp.150.000,00', 'Tablet');

-- --------------------------------------------------------

--
-- Table structure for table `tb_obatmasuk`
--

CREATE TABLE `tb_obatmasuk` (
  `id` int(11) NOT NULL,
  `kode_transaksi` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_obat` int(100) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `jumlah_masuk` int(100) NOT NULL,
  `satuan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_obatmasuk`
--

INSERT INTO `tb_obatmasuk` (`id`, `kode_transaksi`, `tanggal`, `kode_obat`, `nama_obat`, `jumlah_masuk`, `satuan`) VALUES
(1, 'A11689', '2020-06-01', 111, 'Paracetamol', 100, 'Tablet');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_obat`
--
ALTER TABLE `data_obat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manajemen_user`
--
ALTER TABLE `manajemen_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_laporan`
--
ALTER TABLE `tb_laporan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_obatmasuk`
--
ALTER TABLE `tb_obatmasuk`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_obat`
--
ALTER TABLE `data_obat`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `manajemen_user`
--
ALTER TABLE `manajemen_user`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_laporan`
--
ALTER TABLE `tb_laporan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_obatmasuk`
--
ALTER TABLE `tb_obatmasuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
